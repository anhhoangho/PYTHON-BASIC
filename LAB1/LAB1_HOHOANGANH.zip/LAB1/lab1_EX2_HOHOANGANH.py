# Hồ Hoàng ANh _ 22115054122103

# Exercise2
c = float(input("temperature in Celsius: "))
f = 9/5 * c + 32

print('The temperature in Fahrenhetit: ', round(f,1))